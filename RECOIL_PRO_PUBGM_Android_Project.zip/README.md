# RECOIL PRO PUBG Android project

This is an Android WebView wrapper for the RECOIL PRO PUBG sensitivity helper and finger-drag training page.

## Build
Use GitHub Actions workflow `.github/workflows/build-apk.yml` (create it in the repository as a separate file) or open this project in Android Studio and build the debug APK.

The app is a training/settings helper only. It does not modify PUBG Mobile, read game memory, automate aiming, or remove recoil.
