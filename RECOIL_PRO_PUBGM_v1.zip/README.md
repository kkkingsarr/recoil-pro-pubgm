# RECOIL PRO — PUBG Mobile (No Gyro)
Mobile-first PWA prototype for Redmi Note 15 Pro 5G.
Features: editable Camera/ADS sensitivity values, local save, JSON export, touch-drag recoil practice simulator.
This app does not modify PUBG, inject code, read game memory, automate aiming, or guarantee no recoil.
Deploy the `public` folder to HTTPS hosting (Netlify, GitHub Pages, etc.), open on Android Chrome, then choose Install app / Add to Home Screen.
Sensitivity values are editable starter values for testing, not verified device-specific optimal values.
